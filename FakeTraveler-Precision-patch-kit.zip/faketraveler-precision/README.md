# FakeTraveler Precision — patch kit

This archive is a **patch kit**, not the full upstream source. It requires downloading the original FakeTraveler repository from https://github.com/mcastillof/FakeTraveler and applying `apply_precision.py` at the repository root. This is not a verified APK or a tested full project.

## Instructions
1. Download the original repository ZIP and extract it.
2. Copy `apply_precision.py` into the root folder (beside `gradlew`).
3. Run `python3 apply_precision.py`.
4. Build using the original project's Gradle wrapper (`./gradlew assembleDebug`).
5. Install the debug APK, allowing mock locations in Android developer options.

The patch rounds the numeric values just before passing them to the mock location service. This is not a promise about the textual number of digits other apps display, and does not remove Android's mock-location flag.

## Source and license
Upstream: Matías Castillo Felmer, FakeTraveler, GPL-3.0-or-later. Preserve upstream copyright and license when redistributing modified builds.
