#!/usr/bin/env python3
"""Patch FakeTraveler MainActivity to round mock coordinates to 5 decimals."""
from pathlib import Path
p=Path('app/src/main/java/cl/coders/faketraveler/MainActivity.java')
if not p.exists(): raise SystemExit('Run in the original FakeTraveler repository root')
s=p.read_text()
needle='''lat = Double.parseDouble(editTextLat.getText().toString());
        lng = Double.parseDouble(editTextLng.getText().toString());'''
replacement='''lat = Math.round(Double.parseDouble(editTextLat.getText().toString()) * 100000.0d) / 100000.0d;
        lng = Math.round(Double.parseDouble(editTextLng.getText().toString()) * 100000.0d) / 100000.0d;'''
if replacement in s: raise SystemExit('Already patched')
if needle not in s:
    # tolerate indentation differences, but require exact expressions
    import re
    pattern=r'lat\s*=\s*Double\.parseDouble\(editTextLat\.getText\(\)\.toString\(\)\);\s*lng\s*=\s*Double\.parseDouble\(editTextLng\.getText\(\)\.toString\(\)\);'
    s,n=re.subn(pattern,replacement,s,count=1)
    if n!=1: raise SystemExit('Upstream source changed: expected coordinate parsing not found; no changes made')
else:s=s.replace(needle,replacement,1)
p.write_text(s)
print('Applied 5-decimal rounding at Apply action.')
